package br.ada.customer.crud.model;

public enum OrderStatus {

    OPEN, PENDING_PAYMENT, PAID, SHIPPING, FINISH;

}
