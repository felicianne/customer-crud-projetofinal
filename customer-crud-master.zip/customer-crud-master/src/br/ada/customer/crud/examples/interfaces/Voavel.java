package br.ada.customer.crud.examples.interfaces;

public interface Voavel {

    void decolar();

    void voar();

    void pousar();

}
