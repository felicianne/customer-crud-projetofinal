package br.ada.customer.crud.examples.exception;

public class SemBateriaException extends Exception {

}
