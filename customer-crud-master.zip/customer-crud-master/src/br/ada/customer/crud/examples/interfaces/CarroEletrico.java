package br.ada.customer.crud.examples.interfaces;

public class CarroEletrico extends Carro {

}
