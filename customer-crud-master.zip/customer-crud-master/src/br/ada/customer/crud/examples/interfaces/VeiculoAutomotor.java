package br.ada.customer.crud.examples.interfaces;

public interface VeiculoAutomotor extends Veiculo {

    void ligarMotores();

    void desligarMotores();

}
