package br.ada.customer.crud.examples.banco;

public class ContaSemSaldoException extends RuntimeException {
}
