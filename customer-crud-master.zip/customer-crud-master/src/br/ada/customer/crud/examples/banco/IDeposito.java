package br.ada.customer.crud.examples.banco;

import java.math.BigDecimal;

public interface IDeposito {

    void depositar(BigDecimal bigDecimal);

}
