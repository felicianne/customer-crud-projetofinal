package br.ada.customer.crud.examples.interfaces;

public class Bicicleta implements Veiculo {
    @Override
    public void deslocar() {

    }
}
