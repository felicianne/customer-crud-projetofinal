package br.ada.customer.crud.examples.banco;

import java.math.BigDecimal;

public interface ISaque {

    void sacar(BigDecimal valor);

}
