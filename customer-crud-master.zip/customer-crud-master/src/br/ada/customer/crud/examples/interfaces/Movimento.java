package br.ada.customer.crud.examples.interfaces;

public interface Movimento {

    void deslocar();

}
