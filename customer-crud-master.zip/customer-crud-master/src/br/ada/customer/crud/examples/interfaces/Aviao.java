package br.ada.customer.crud.examples.interfaces;

public class Aviao implements Voavel, VeiculoAutomotor {

    @Override
    public void ligarMotores() {

    }

    @Override
    public void desligarMotores() {

    }

    @Override
    public void deslocar() {

    }

    @Override
    public void decolar() {

    }

    @Override
    public void voar() {

    }

    @Override
    public void pousar() {

    }

}
