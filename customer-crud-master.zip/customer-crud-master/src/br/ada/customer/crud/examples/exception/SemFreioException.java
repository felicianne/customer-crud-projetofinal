package br.ada.customer.crud.examples.exception;

public class SemFreioException extends RuntimeException {
}
