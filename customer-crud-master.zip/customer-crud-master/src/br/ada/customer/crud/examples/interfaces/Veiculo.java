package br.ada.customer.crud.examples.interfaces;

public interface Veiculo extends Movimento {


}
